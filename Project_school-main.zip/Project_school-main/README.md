# Project_school
Проект по теме: "Контроль безопасного доступа в кабинеты"
Создание сайта с отображением, отслеживанием посещения кабинетов, при использовании зарегестрированных NFC чипов, наличие разных прав доступа.

логотип:
![image](https://github.com/user-attachments/assets/f6566a6d-12af-4f24-a2d6-6e9afc6b4927)


Окно авторизации:
![image](https://github.com/user-attachments/assets/88fc7502-0602-4c31-95de-b4ce120e6083)

Окно истории:
![image](https://github.com/user-attachments/assets/ccfb0880-94ed-4308-91d2-c37fa204fb27)

Окно профиля:
![image](https://github.com/user-attachments/assets/ce203705-5e06-47aa-83c4-4dce304028b0)

админ панель:
![image](https://github.com/user-attachments/assets/26ffcab8-87c4-4ff5-88db-3fed3e6354e3)

![image](https://github.com/user-attachments/assets/a511b197-c176-4db5-9e43-99c2c3b53f49)

Технологии: Python, PYQT6, SQL, sqlite3.



