import sys
import sqlite3
from PyQt6 import QtCore, QtGui, uic
from PyQt6.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
from PyQt6.QtWidgets import QLabel, QLineEdit, QMainWindow, QStatusBar
from PyQt6.QtGui import QPixmap
from home_page import *
from main import *
import config
import hashlib
from admin import *






class auth_window(QMainWindow):
    def __init__(self, *args):
        # Надо не забыть вызвать инициализатор базового класса
        super().__init__()
        # В метод initUI() будем выносить всю настройку интерфейса,
        # чтобы не перегружать инициализатор
        self.auth(args)

    def auth(self, args):
        # Зададим размер и положение нашего виджета,
        uic.loadUi('auth.ui', self)

        self.authbtm.clicked.connect(self.open_home)
        self.regisbtm.clicked.connect(self.add_record)






    def add_record(self):
        login = self.login.text()
        password = self.passw.text()
        ex = cursor.execute(f"SELECT id, login, password, passlvl FROM Users WHERE login='{login}'")
        res = ex.fetchall()
        if len(res) > 0:
            self.statusbar.showMessage('такой логин уже есть')
        else:
            # Хэширование пароля, введеное в поле, по протоколу sha256
            code = hashlib.sha256(password.encode('utf-8'))
            paswd = code.digest()
            paswdhex = paswd.hex()
            # Проверяем что хэш пароля, введенного с поля, совпадает с хэшэм в БД
            # Сохранение данные пользователя
            password = paswdhex
            cursor.execute(f"INSERT INTO Users(login, password) VALUES {login, password}")
            connection.commit()





    def open_home(self):
        login = self.login.text()
        password = self.passw.text()
        # Проверяем что поля не пустые
        if login == "" and password == "":
            self.statusbar.showMessage("Не введен логин и пароль...")
        # Проверка что поле логин не пустое
        elif login == "":
            self.statusbar.showMessage("Не введен логин...")
        # Проверка что поле пароль не пустое
        elif password == "":
            self.statusbar.showMessage("Не введен пароль...")

        # Проверка что поля не пустые
        if login != "" and password != "":
            # Запрос на существование пользователя в БД
            ex = cursor.execute(f"SELECT id, login, password, passlvl FROM Users WHERE login='{login}'")
            res = ex.fetchall()
            # Проверка что такое пользователь существует
            if len(res) > 0:
                # Хэширование пароля, введеное в поле, по протоколу sha256
                code = hashlib.sha256(password.encode('utf-8'))
                paswd = code.digest()
                paswdhex = paswd.hex()
                # Проверяем что хэш пароля, введенного с поля, совпадает с хэшэм в БД

                if paswdhex == res[0][2]:
                    config.user = login
                    config.password = password
                    config.id_role = res[0][3]
                    config.id_user = res[0][0]

                    passlvl = cursor.execute(f"SELECT passlvl FROM Users WHERE login='{login}'")
                    passlvl = passlvl.fetchall()
                    print(passlvl)
                    if passlvl == [('2',)]:
                        #Переход в окно админ-панели
                        self.close()
                        self.admin_window = admin_window(self)
                        self.admin_window.show()

                    elif passlvl == [('1',)]:
                        #переход на страницу пользователя
                        self.close()
                        self.home = home(self)
                        self.home.show()

                    elif passlvl == [('0',)]:
                        self.statusbar.showMessage("Не дочтаточно прав попросите администратора выдать вам права.")


            else:
                self.statusbar.showMessage("нет такого пользователя в системе.")











