import sys
import sqlite3
from PyQt6 import QtCore, QtGui, uic
from PyQt6.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
from PyQt6.QtWidgets import QLabel, QLineEdit
from PyQt6.QtGui import QPixmap
from authorisation import *
import hashlib

connection = sqlite3.connect('my_database.db')
cursor = connection.cursor()
cursor.execute('''
CREATE TABLE IF NOT EXISTS Users (
id INTEGER PRIMARY KEY,
login TEXT NOT NULL,
password TEXT NOT NULL,
passlvl TEXT NOT NULL DEFAULT 1
)
''')


cursor.execute('''
CREATE TABLE IF NOT EXISTS cabinets (
id INTEGER PRIMARY KEY,
number TEXT NOT NULL,
date TEXT NOT NULL DEFAULT 'none'
)
''')
login = 'a'
password = 'a'
ex = cursor.execute(f"SELECT id, login, password, passlvl FROM Users WHERE login='{login}'")
res = ex.fetchall()
if len(res) > 0:
    print('')
else:
    code = hashlib.sha256(password.encode('utf-8'))
    paswd = code.digest()
    paswdhex = paswd.hex()
    cursor.execute(f"INSERT INTO Users(login, password, passlvl) VALUES {login, paswdhex, '2'}")
    connection.commit()







class mainn(QMainWindow):
    def __init__(self, *args):
        # Надо не забыть вызвать инициализатор базового класса
        super().__init__()
        # Зададим размер и положение нашего виджета,
        self.setGeometry(1100, 500, 640, 480)
        # А также его заголовок
        self.setWindowTitle('главная')

        self.namesait = QLabel('Система контроля доступа в кабинеты', self)
        self.namesait.resize(250, 50)
        self.namesait.move(225, 0)

        # Кнопка Авторизации
        self.startbtm = QPushButton('начать использование', self)
        self.startbtm.resize(150, 50)
        self.startbtm.move(250, 100)

        self.startbtm.clicked.connect(self.open_auth)


    def open_auth(self):
        self.close()
        self.auth_window = auth_window(self)
        self.auth_window.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = mainn()
    ex.show()
    sys.exit(app.exec())
    connection.close()