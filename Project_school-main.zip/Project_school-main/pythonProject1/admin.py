import sys
import sqlite3
from PyQt6 import QtCore, QtGui, uic
from PyQt6.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
from PyQt6.QtWidgets import QLabel, QLineEdit, QMainWindow, QStatusBar
from PyQt6.QtGui import QPixmap
from home_page import *
from main import *
import config
import hashlib






class admin_window(QMainWindow):
    def __init__(self, *args):
        # Надо не забыть вызвать инициализатор базового класса
        super().__init__()
        # В метод initUI() будем выносить всю настройку интерфейса,
        # чтобы не перегружать инициализатор
        self.adminpanel(args)

    def adminpanel(self, args):
        # Зададим размер и положение нашего виджета,
        uic.loadUi('Admin.ui', self)

        ex = cursor.execute(f"SELECT login, passlvl FROM Users")
        res = ex.fetchall()

