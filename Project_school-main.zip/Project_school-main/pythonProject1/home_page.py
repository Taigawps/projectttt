import sys
import sqlite3
from PyQt6 import QtCore, QtGui, uic, QtWidgets
from PyQt6.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
from PyQt6.QtWidgets import QLabel, QLineEdit
from PyQt6.QtGui import QPixmap
from authorisation import *
from main import *
import config



class home(QMainWindow):
    def __init__(self, *args):
        super().__init__()
        uic.loadUi('Main.ui', self)

        self.username.setText(f'{config.user}: уровень допуска:{config.id_role}')

        self.exitaccaunt.clicked.connect(self.exittt)

    def exittt(self):
        self.close()
        self.auth_window = auth_window(self)
        self.auth_window.show()














